package org.webley.codingAssignment;

import java.io.File;
import java.io.FileInputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * @author swapnilbalakrishna7
 *
 */
public class CombinationDishes {

	/**
	 * The target price.
	 */
	private static int targetPrice;

	/**
	 * Copy of the prices (in integer format) that was used to generate this
	 * solution
	 */
	private int[] prices;

	/**
	 * List of all possible combinations for the target
	 */
	private ArrayList<String> allPossibleCombinations = new ArrayList<String>();

	/**
	 * Map to store the price,dish pair
	 */
	private static Map<Double, String> data = new TreeMap<Double, String>();

	/**
	 * Constructor to intialize targetPrice and prices[]
	 * 
	 * @param targetPrice
	 *            - The target price
	 * @param prices
	 *            - Array containing all the prices
	 */
	public CombinationDishes(int targetPrice, int[] prices) {
		CombinationDishes.targetPrice = targetPrice;
		this.prices = prices;
	}

	public static boolean isSheetEmpty = false;

	/**
	 * Find all possible solutions recursively
	 * 
	 * @param currentSoln
	 *            - The current solution string
	 * @param startIndex
	 *            - The start index in the price array.
	 * @param remainingTarget
	 *            - The remaining target amount to be satisfied.
	 * @param finalResult
	 *            - The final result object.
	 */
	public void findAllCombinationsRecursive(String currentSoln,
			int startIndex, int remainingTarget, CombinationDishes finalResult) {

		for (int i = startIndex; i < prices.length; i++) {
			int temp = remainingTarget - prices[i];
			String tempSoln = currentSoln + ""
					+ CombinationDishes.data.get((double) (prices[i]) / 100)
					+ " | ";
			if (temp < 0) {
				break;
			}
			if (temp == 0) {
				// reached the solution hence quit from the loop
				finalResult.allPossibleCombinations.add(tempSoln);
				break;
			} else {
				// target not reached, try the solution recursively with the
				// current price as the start point.
				findAllCombinationsRecursive(tempSoln, i, temp, finalResult);
			}
		}
	}

	/**
	 * Helper method to call the findAllCombinationsRecursive method
	 * 
	 * @param targetPrice
	 *            - The target price
	 * @param prices
	 *            - Array containing all the prices
	 */
	public CombinationDishes findAllPossibleCombinations(int targetPrice,
			int[] prices) {
		CombinationDishes soln = new CombinationDishes(targetPrice, prices);
		String tempSoln = new String();
		findAllCombinationsRecursive(tempSoln, 0, targetPrice, soln);
		return soln;
	}

	/**
	 * Method to read from Excel file
	 * 
	 * @param path
	 *            - The path of the file to be read
	 */
	public static void readFile(String path) {
		try {

			FileInputStream file = new FileInputStream(new File(path));
			// Create Workbook instance holding reference to .xlsx file
			XSSFWorkbook workbook = new XSSFWorkbook(file);
			// Get first/desired sheet from the workbook
			XSSFSheet sheet = workbook.getSheetAt(0);
			if (isSheetEmpty(sheet))
				System.err
						.println("Excel sheet is empty. Please input a valid excel sheet!");
			// Iterate through each rows one by one
			Iterator<Row> rowIterator = sheet.iterator();
			while (rowIterator.hasNext()) {
				Row row = rowIterator.next();
				// For each row, iterate through all the columns
				Iterator<Cell> cellIterator = row.cellIterator();
				while (cellIterator.hasNext()) {
					// First Cell
					Cell cell = cellIterator.next();
					// To get the first Column (Dish)
					String dish = cell.getStringCellValue();
					// Second Cell
					cell = cellIterator.next();
					// Getting the target price from the first row
					if (dish.equalsIgnoreCase("Target Price")) {
						// Converting target price to Integer for ease of
						// computation
						targetPrice = (int) (cell.getNumericCellValue() * 100);
						continue;
					}
					// To get the second Column (Price)
					Double price = cell.getNumericCellValue();
					// If there are multiple dishes with the same price...we
					// seperate them by "/"
					String tmpDish = "";
					if ((tmpDish = data.get(price)) != null) {
						dish = dish + "/" + tmpDish;
					}
					data.put(price, dish);
				}
			}
			workbook.close();
			file.close();
		} catch (Exception e) {
			System.err.println(e);
		}
	}

	/**
	 * Method to check if the sheet is empty
	 * 
	 * @param sheet
	 *            - Current sheet of excel file
	 * @return
	 */
	public static boolean isSheetEmpty(XSSFSheet sheet) {
		Iterator<Row> rows = sheet.rowIterator();
		while (rows.hasNext()) {
			XSSFRow row = (XSSFRow) rows.next();
			Iterator<Cell> cells = row.cellIterator();
			while (cells.hasNext()) {
				XSSFCell cell = (XSSFCell) cells.next();
				if (!cell.getRawValue().isEmpty()) {
					isSheetEmpty = false;
				}
			}
		}
		return isSheetEmpty;
	}

	public static void main(String args[]) {
		String path = "";
		// To get the URL of the default .xlsx file if file not specified on
		// command line
		URL url = CombinationDishes.class.getResource("/Menu.xlsx");
		if (args.length > 0)
			path = args[0];
		else
			path = url.getPath();
		// path = "/Users/swapnilbalakrishna7/Desktop/Menu.xlsx";
		readFile(path);
		int[] prices = new int[data.size()];
		int i = 0;
		// Storing all the prices in Integer format by * 100 for ease of
		// computation
		for (Map.Entry<Double, String> entry : data.entrySet()) {
			prices[i] = (int) (entry.getKey() * 100);
			i++;
		}
		CombinationDishes combinationDishes = new CombinationDishes(
				targetPrice, prices);
		CombinationDishes results = combinationDishes
				.findAllPossibleCombinations(targetPrice, prices);
		int count = 0;
		// Printing results
		if (results.allPossibleCombinations.size() == 0 && !isSheetEmpty) {
			System.out
					.println("There is no combination of dishes that is equal to the target price");
		} else {
			for (String result : results.allPossibleCombinations) {
				System.out.println("Combination " + (++count) + ": " + result);
				System.out
						.println("--------------------------------------------------------------------");
			}
		}

	}
}